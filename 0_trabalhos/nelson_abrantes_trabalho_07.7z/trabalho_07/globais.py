
produtos = []
vendas = []